package com.example.hari_flutter_site

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
